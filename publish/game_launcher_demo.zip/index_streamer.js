import { registerApp } from '@hyext-beyond/core'
import App from './streamer/app'

registerApp('streamer', App)
